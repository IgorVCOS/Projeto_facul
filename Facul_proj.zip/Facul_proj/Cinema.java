import java.util.Scanner;

public class Cinema{
    public static void main (String[] args){
        int filme;
        int comida;
        int bebida;
        String filmeEscolhido;
        String comidaEscolhida;
        String bebidaEscolhida;


        try (Scanner escolha = new Scanner(System.in)) {
         System.out.println("BEM-VINDO AO CINE & CIA, ONDE SEU FILME SE TORNA ESPECIAL");
           System.out.println("\n\n Escolha 1 dessas três opções de filmes:" + " O preço do ingresso é de R$20");
           System.out.println("Digite (1)Adão negro; (2)The Flash; (3)The Batman");
            filme = escolha.nextInt();

            if(filme == 1){
               System.out.println("Você escolheu Adão negro");
               filmeEscolhido = "Adão negro";
               filme = 20;
            } else if(filme == 2){
               System.out.println("Você escolheu The Flash");
               filmeEscolhido = "The Flash";
               filme = 20;
            }else if(filme == 3){
               System.out.println("Você escolheu The Batman");
               filmeEscolhido = "The Batman";
               filme = 20;
            }else{
               System.out.println("Você não escolheu nada");
               filmeEscolhido = "Não foi escolhido um filme";
               filme = 0;
            }


            System.out.println("\n\n Escolha 1 dessas três opções de Comida:");
            System.out.println("Digite (1)Pipoca Salgada; (2)Pipoca doce; (3)Salgadinhos & chocolates");
            System.out.println("\n\n Pipoca salgada = R$30" + " Pipoca doce = R$35" + " Salgadinhos & chocolates = R$20");
            comida = escolha.nextInt();

             if(comida == 1){
               System.out.println("Você escolheu Pipoca salgada");
               comidaEscolhida = "Pipoca salgada";
               comida = 30;
            } else if(comida == 2){
               System.out.println("Você escolheu Pipoca doce");
               comidaEscolhida = "Pipoca doce";
               comida = 35;
            }else if(comida == 3){
               System.out.println("Você escolheu Salgadinhos & chocolates");
               comidaEscolhida = "Salgadinhos & chocolates";
               comida = 20;
            }else{
               System.out.println("Você não escolheu nada");
               comidaEscolhida = "Não foi escolhida uma comida";
               comida = 0;
            };

            System.out.println("\n\n Escolha 1 dessas três opções de Bebida:");
            System.out.println("Digite (1)Água; (2)Refrigerante; (3)Energético");
            System.out.println("\n\n Água = R$5" + " Refrigerante = R$15" + " Energético = R$10");
            bebida = escolha.nextInt();
      }

        if(bebida == 1){
            System.out.println("Você escolheu Água");
            bebidaEscolhida = "Água";
            bebida = 5;
         } else if(bebida == 2){
            System.out.println("Você escolheu Refrigerante");
            bebidaEscolhida = "Refrigerante";
            bebida = 15;
         }else if(bebida == 3){
            System.out.println("Você escolheu Energético");
            bebidaEscolhida = "Energético";
            bebida = 10;
         }else{
            System.out.println("Você não escolheu nada");
            bebidaEscolhida = "Não foi escolhida uma bebida";
            bebida = 0;
         };

         int total = filme + comida + bebida;

         System.out.println("\n\n Suas escolhas foram:" + " filme: " + filmeEscolhido + "\n\n Comida: " + comidaEscolhida 
         + "\n\n Bebida: " + bebidaEscolhida );

         System.out.println("\n\n O TOTAL FOI DE: " + total);

         System.out.println("\n\n BOM FILME!!");

         System.out.println("\n\n RETIRE SEUS PEDIDOS COM O ATENTENDE!\n\n VOLTE SEMPRE!");
             
    }
}